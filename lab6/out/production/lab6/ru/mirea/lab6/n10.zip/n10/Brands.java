package ru.mirea.lab6.n10;

public enum Brands {
    ASUS,
    DELL,
    HP,
    MSI;
}
